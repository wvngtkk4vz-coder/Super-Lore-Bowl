# Blood Realm: Fighting Universe

A single-page fighting universe game. Open `index.html` in any browser.
